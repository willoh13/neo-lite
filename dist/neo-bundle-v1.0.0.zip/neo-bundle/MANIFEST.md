# NEO Lite Skills Bundle v1.0.0

## What's included

### Parts (add-on capability packs)
- `parts/scraper/` — Web scraper for news, real estate, job boards, etc.
- `parts/support-agent/` — Self-service customer support agent (reads the FAQ, walks through install, escalates to humans only when stuck)

### Skills (workflows NEO knows how to run)
- `skills/neo-lite-planner/` — Goal → step-by-step plan
- `skills/neo-lite-researcher/` — Multi-source research with citations

### Tools (utilities NEO can call)
- `tools/delegation-scoring-matrix/` — Picks which task to do first when you ask NEO to do 5 things at once
- `tools/language-selection-matrix/` — Picks the best AI provider per task
- `tools/neo-build-orchestrator/` — Runs multi-step build pipelines

### Config
- `config/config.yaml` — Default NEO personality configuration

## Install

This bundle is meant to be extracted on top of a base Hermes Agent install. It will be installed automatically by the NEO Lite installer in Step 1.6 of INSTALL-WINDOWS-NATIVE.md.

If installing manually:
1. Extract to `%LOCALAPPDATA%\hermes\`
2. Restart the gateway: `hermes gateway restart`

## License

MIT. Free to use, modify, redistribute. See https://github.com/willoh13/neo-lite/blob/main/LICENSE

## Version history

### v1.0.0 (2026-07-15)
- Initial release
- 2 parts, 2 skills, 3 tools
- Includes NEO Agent 2 default personality
